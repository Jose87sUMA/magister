# Magister
## Grupo J

Para ejecutar desplegar, en el directorio del proyecto ejecutar los comandos:
- `npm install` para instalar las dependencias.
- `npm start` para ejecutar la aplicación.
La pagina web estara disponible en [http://localhost:3000](http://localhost:3000).
